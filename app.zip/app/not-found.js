export default function NotFound() {
    return (
        <main>
            <h1>Not Found</h1>
            <p>Unfortunately not found the page</p>
        </main>
    )
}