export default function notFound() {
    return (
        <main className="not-found">
            <h1> meal Not Found</h1>
            <p>Unfortunately not found the page</p>
        </main>
    )
}