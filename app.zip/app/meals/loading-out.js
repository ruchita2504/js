import classes from './loading.module.css';

export default function LoadingPage(){
    return (
        <p className={classes.loading}>Fetching meals....</p>
    );
}